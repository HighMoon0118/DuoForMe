-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: duofor.me    Database: duoforme
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `riotusertier`
--

DROP TABLE IF EXISTS `riotusertier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `riotusertier` (
  `riotusertier_id` int NOT NULL AUTO_INCREMENT,
  `riotuser_lol_nickname` varchar(45) DEFAULT NULL,
  `queue_type` varchar(50) DEFAULT NULL,
  `tier` varchar(45) DEFAULT NULL,
  `rank_number` varchar(45) DEFAULT NULL,
  `win` int DEFAULT NULL,
  `lose` int DEFAULT NULL,
  PRIMARY KEY (`riotusertier_id`),
  KEY `fk_riotusertier_riotuser1_idx` (`riotuser_lol_nickname`),
  CONSTRAINT `fk_riotusertier_riotuser1` FOREIGN KEY (`riotuser_lol_nickname`) REFERENCES `riotuser` (`lol_nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='																																																																																																																																																	';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `riotusertier`
--

LOCK TABLES `riotusertier` WRITE;
/*!40000 ALTER TABLE `riotusertier` DISABLE KEYS */;
INSERT INTO `riotusertier` VALUES (1,'민주지산','RANKED_SOLO_5x5','SILVER','III',33,38),(2,'엄돼지','RANKED_SOLO_5x5','PLATINUM','II',174,167),(3,'Hide on bush','RANKED_SOLO_5x5','CHALLENGER','I',737,683),(7,'all sundaykak','RANKED_SOLO_5x5','SILVER','IV',100,133),(9,'베이GOD','RANKED_SOLO_5x5','PLATINUM','IV',239,233),(10,'도모찌','RANKED_SOLO_5x5','GOLD','III',24,18),(12,'내셔 바론','RANKED_SOLO_5x5','SILVER','I',31,35),(13,'내셔 바론','RANKED_SOLO_5x5','SILVER','I',31,35),(14,'내셔 바론','RANKED_SOLO_5x5','SILVER','I',31,35),(15,'내셔 바론','RANKED_SOLO_5x5','SILVER','I',31,35),(16,'아 가','RANKED_SOLO_5x5','PLATINUM','IV',259,251),(19,'커피물조절장인','RANKED_SOLO_5x5','GRANDMASTER','I',974,921),(20,'아 리','RANKED_SOLO_5x5','PLATINUM','II',35,26),(21,'VRIZ돌짐승','RANKED_SOLO_5x5','PLATINUM','III',94,74),(27,'선상욱','RANKED_SOLO_5x5','MASTER','I',616,605),(30,'사리니','RANKED_SOLO_5x5','DIAMOND','II',454,437),(32,'보노뭘보노','RANKED_SOLO_5x5','SILVER','IV',5,7),(33,'해코스','RANKED_SOLO_5x5','SILVER','II',274,278),(34,'털바퀴혐오자','RANKED_SOLO_5x5','GOLD','IV',180,186),(35,'오골딱','RANKED_SOLO_5x5','GOLD','II',30,26),(36,'뽀똥이','RANKED_SOLO_5x5','SILVER','II',30,20),(37,'오노밥','RANKED_SOLO_5x5','GOLD','II',103,86),(38,'호구섭','RANKED_SOLO_5x5','GOLD','I',94,69),(39,'극강청','RANKED_SOLO_5x5','PLATINUM','III',215,186),(42,'성수성수 ','RANKED_SOLO_5x5','GOLD','II',9,15),(43,'나니의표본','RANKED_SOLO_5x5','PLATINUM','IV',229,214),(44,'쥐잡는요리사','RANKED_SOLO_5x5','SILVER','IV',43,53),(45,'성수성수 ','RANKED_SOLO_5x5','GOLD','II',9,15),(47,'절대킹카','RANKED_SOLO_5x5','SILVER','IV',176,180),(50,'트집쟁이','RANKED_SOLO_5x5','GOLD','IV',57,61),(51,'녕 잉','RANKED_SOLO_5x5','SILVER','II',314,352),(52,'명노잼','RANKED_SOLO_5x5','SILVER','I',8,16),(54,'유쇼유','RANKED_SOLO_5x5','GOLD','IV',408,397),(55,'사마귀튀김','RANKED_SOLO_5x5','SILVER','III',33,33),(56,'물면잡아','RANKED_SOLO_5x5','PLATINUM','IV',753,717),(57,'아아아','RANKED_SOLO_5x5','SILVER','I',165,130);
/*!40000 ALTER TABLE `riotusertier` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-08  2:29:18
